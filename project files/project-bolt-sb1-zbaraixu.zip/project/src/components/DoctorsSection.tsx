import React, { useState } from 'react';
import { doctors } from '../data/mockData';
import { Star, Calendar, Clock, MapPin } from 'lucide-react';
import BookingModal from './BookingModal';

const DoctorsSection: React.FC = () => {
  const [selectedDoctor, setSelectedDoctor] = useState<string | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  const handleBookAppointment = (doctorId: string) => {
    setSelectedDoctor(doctorId);
    setIsBookingModalOpen(true);
  };

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-sky-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Meet Our Expert Doctors
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our team of experienced healthcare professionals is dedicated to providing 
            you with the highest quality medical care.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {doctors.map((doctor) => (
            <div
              key={doctor.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-sky-200 group hover:-translate-y-2"
            >
              <div className="relative">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 bg-white rounded-full px-3 py-1 flex items-center shadow-md">
                  <Star className="w-4 h-4 text-yellow-400 fill-current mr-1" />
                  <span className="text-sm font-semibold">{doctor.rating}</span>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {doctor.name}
                </h3>
                <p className="text-sky-600 font-medium mb-4">
                  {doctor.specialty}
                </p>
                
                <div className="space-y-2 mb-6">
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{doctor.experience} years experience</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mr-2 text-gray-400" />
                    <span>Available {doctor.availability.length} days/week</span>
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-sky-50 to-teal-50 rounded-xl p-4 mb-6">
                  <div className="flex items-center text-sm text-sky-700">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span className="font-medium">Next Available:</span>
                  </div>
                  <div className="text-sm text-sky-600 mt-1">
                    {doctor.nextAvailable}
                  </div>
                </div>
                
                <button
                  onClick={() => handleBookAppointment(doctor.id)}
                  className="w-full bg-gradient-to-r from-sky-500 to-teal-500 text-white py-3 rounded-xl font-semibold hover:from-sky-600 hover:to-teal-600 transition-all duration-200 shadow-sm hover:shadow-md"
                >
                  Book Appointment
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        doctorId={selectedDoctor}
      />
    </section>
  );
};

export default DoctorsSection;