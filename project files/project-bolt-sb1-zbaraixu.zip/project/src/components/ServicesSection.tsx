import React from 'react';
import { services } from '../data/mockData';
import { 
  Stethoscope, 
  Heart, 
  Activity, 
  Shield, 
  Brain, 
  Video,
  Clock,
  DollarSign
} from 'lucide-react';

const iconMap = {
  Stethoscope,
  Heart,
  Activity,
  Shield,
  Brain,
  Video
};

interface ServicesSectionProps {
  setActiveSection: (section: string) => void;
}

const ServicesSection: React.FC<ServicesSectionProps> = ({ setActiveSection }) => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Comprehensive Healthcare Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From routine check-ups to specialized treatments, we offer a complete range of medical services 
            to keep you and your family healthy.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const IconComponent = iconMap[service.icon as keyof typeof iconMap];
            return (
              <div
                key={service.id}
                className="group bg-white rounded-2xl p-8 shadow-sm border border-gray-100 hover:shadow-lg hover:border-sky-200 transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-sky-100 to-teal-100 rounded-2xl flex items-center justify-center group-hover:from-sky-200 group-hover:to-teal-200 transition-all duration-300">
                    <IconComponent className="w-7 h-7 text-sky-600" />
                  </div>
                  <div className="text-right">
                    <div className="flex items-center text-sky-600 font-semibold">
                      <DollarSign className="w-4 h-4" />
                      <span>{service.price}</span>
                    </div>
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {service.name}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {service.description}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{service.duration} minutes</span>
                  </div>
                  <button
                    onClick={() => setActiveSection('doctors')}
                    className="text-sky-600 font-medium hover:text-sky-700 transition-colors duration-200"
                  >
                    Book Now →
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <button
            onClick={() => setActiveSection('doctors')}
            className="bg-gradient-to-r from-sky-500 to-teal-500 text-white px-8 py-4 rounded-xl font-semibold hover:from-sky-600 hover:to-teal-600 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Book an Appointment
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;