import React from 'react';
import { Calendar, Phone, Mail, User } from 'lucide-react';

interface HeaderProps {
  activeSection: string;
  setActiveSection: (section: string) => void;
}

const Header: React.FC<HeaderProps> = ({ activeSection, setActiveSection }) => {
  return (
    <header className="bg-white/95 backdrop-blur-md shadow-sm border-b border-sky-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="ml-3 text-xl font-bold bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">
                HealthBook
              </span>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <button
              onClick={() => setActiveSection('home')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeSection === 'home'
                  ? 'text-sky-600 bg-sky-50'
                  : 'text-gray-600 hover:text-sky-600 hover:bg-sky-50'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setActiveSection('services')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeSection === 'services'
                  ? 'text-sky-600 bg-sky-50'
                  : 'text-gray-600 hover:text-sky-600 hover:bg-sky-50'
              }`}
            >
              Services
            </button>
            <button
              onClick={() => setActiveSection('doctors')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeSection === 'doctors'
                  ? 'text-sky-600 bg-sky-50'
                  : 'text-gray-600 hover:text-sky-600 hover:bg-sky-50'
              }`}
            >
              Doctors
            </button>
            <button
              onClick={() => setActiveSection('dashboard')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeSection === 'dashboard'
                  ? 'text-sky-600 bg-sky-50'
                  : 'text-gray-600 hover:text-sky-600 hover:bg-sky-50'
              }`}
            >
              Dashboard
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            <div className="hidden lg:flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-1" />
                <span>(555) 123-4567</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-1" />
                <span>help@healthbook.com</span>
              </div>
            </div>
            <button className="bg-gradient-to-r from-sky-500 to-teal-500 text-white px-4 py-2 rounded-lg font-medium hover:from-sky-600 hover:to-teal-600 transition-all duration-200 flex items-center">
              <User className="w-4 h-4 mr-2" />
              Sign In
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;