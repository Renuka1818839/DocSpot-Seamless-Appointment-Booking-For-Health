import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ServicesSection from './components/ServicesSection';
import DoctorsSection from './components/DoctorsSection';
import Dashboard from './components/Dashboard';
import Footer from './components/Footer';

function App() {
  const [activeSection, setActiveSection] = useState('home');

  const renderContent = () => {
    switch (activeSection) {
      case 'services':
        return <ServicesSection setActiveSection={setActiveSection} />;
      case 'doctors':
        return <DoctorsSection />;
      case 'dashboard':
        return <Dashboard />;
      default:
        return (
          <>
            <Hero setActiveSection={setActiveSection} />
            <ServicesSection setActiveSection={setActiveSection} />
            <DoctorsSection />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header activeSection={activeSection} setActiveSection={setActiveSection} />
      <main>
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
}

export default App;