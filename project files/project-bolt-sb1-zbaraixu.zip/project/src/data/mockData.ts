import { Doctor, Service, Appointment } from '../types';

export const doctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialty: 'General Practice',
    rating: 4.9,
    experience: 12,
    image: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=400',
    availability: ['Monday', 'Tuesday', 'Wednesday', 'Friday'],
    nextAvailable: 'Tomorrow at 10:00 AM'
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialty: 'Cardiology',
    rating: 4.8,
    experience: 15,
    image: 'https://images.pexels.com/photos/6749778/pexels-photo-6749778.jpeg?auto=compress&cs=tinysrgb&w=400',
    availability: ['Monday', 'Wednesday', 'Thursday', 'Friday'],
    nextAvailable: 'Today at 2:30 PM'
  },
  {
    id: '3',
    name: 'Dr. Emily Rodriguez',
    specialty: 'Dermatology',
    rating: 4.9,
    experience: 8,
    image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400',
    availability: ['Tuesday', 'Wednesday', 'Thursday', 'Saturday'],
    nextAvailable: 'Friday at 11:30 AM'
  },
  {
    id: '4',
    name: 'Dr. James Wilson',
    specialty: 'Orthopedics',
    rating: 4.7,
    experience: 18,
    image: 'https://images.pexels.com/photos/6749774/pexels-photo-6749774.jpeg?auto=compress&cs=tinysrgb&w=400',
    availability: ['Monday', 'Tuesday', 'Friday', 'Saturday'],
    nextAvailable: 'Monday at 9:00 AM'
  }
];

export const services: Service[] = [
  {
    id: '1',
    name: 'General Consultation',
    description: 'Comprehensive health check-up and medical consultation',
    duration: 30,
    price: 120,
    icon: 'Stethoscope'
  },
  {
    id: '2',
    name: 'Specialist Consultation',
    description: 'Expert consultation with medical specialists',
    duration: 45,
    price: 200,
    icon: 'Heart'
  },
  {
    id: '3',
    name: 'Diagnostic Tests',
    description: 'Lab tests, imaging, and diagnostic procedures',
    duration: 60,
    price: 150,
    icon: 'Activity'
  },
  {
    id: '4',
    name: 'Preventive Care',
    description: 'Vaccinations, screenings, and preventive health services',
    duration: 20,
    price: 80,
    icon: 'Shield'
  },
  {
    id: '5',
    name: 'Mental Health',
    description: 'Psychological counseling and mental health support',
    duration: 60,
    price: 180,
    icon: 'Brain'
  },
  {
    id: '6',
    name: 'Telemedicine',
    description: 'Virtual consultations from the comfort of your home',
    duration: 25,
    price: 100,
    icon: 'Video'
  }
];

export const mockAppointments: Appointment[] = [
  {
    id: '1',
    doctorId: '1',
    doctorName: 'Dr. Sarah Johnson',
    service: 'General Consultation',
    date: '2024-01-15',
    time: '10:00 AM',
    status: 'confirmed',
    patientName: 'John Doe',
    patientEmail: 'john@example.com'
  },
  {
    id: '2',
    doctorId: '2',
    doctorName: 'Dr. Michael Chen',
    service: 'Cardiology Consultation',
    date: '2024-01-18',
    time: '2:30 PM',
    status: 'pending',
    patientName: 'John Doe',
    patientEmail: 'john@example.com'
  }
];