export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  rating: number;
  experience: number;
  image: string;
  availability: string[];
  nextAvailable: string;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  duration: number;
  price: number;
  icon: string;
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  service: string;
  date: string;
  time: string;
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled';
  patientName: string;
  patientEmail: string;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}